# Local-Business-Padma-Shop-Insights-Dashboard
( Power Query | Power BI )

#Empowering Local Business
#Designed a interactive dashboard to understand  sales ,region of profit & loss. 
#The final Dashboard was effective at displaying the sales trends.
#Used different types of customized visualization (bar chart, pie chart, donut chart, clustered bar chart, scatter chart, line chart, area chart, map, slicers, etc) which helped me to figure out a strategy to increase profits. 
#This dashboard could help in increasing the revenue at least by 20% in the next quarter.


Real Life Problem: I stay in a village called Mandamarri,In our street we used to have a grocery store,where more than 200 families used to take groceries every month.But i came to hear that the Owner is going to close the store because they are having very less margin of profit and few months they are having losses even.This is totally due to bad management.So as a Data Analyst i took the responsibility to have the insights of the sales of the store,So that i can provide a strategy so that the store owners can land in profits .I got the data of last one year from the sales computer which they store.


Entire Dashboard: 

![Entire Dashboard](https://github.com/Sanjoe27/Local-Business-Padma-Shop-Insights-Dashboard/assets/98551759/2088e0ce-fd32-43d0-a7fd-539f49c35385)


Quarter 1:

![Quarter 1](https://github.com/Sanjoe27/Local-Business-Padma-Shop-Insights-Dashboard/assets/98551759/f5013651-15fe-402b-bfd6-58216cbd23c4)


Quarter 2:

![Quarter 2](https://github.com/Sanjoe27/Local-Business-Padma-Shop-Insights-Dashboard/assets/98551759/c8c2765a-4561-422b-9571-0e7e8c6b163e)



Quarter 3:

![Quarter 3](https://github.com/Sanjoe27/Local-Business-Padma-Shop-Insights-Dashboard/assets/98551759/52ce9adf-5b0b-4807-ba2e-c4167251398b)


Quarter 4:

![Quarter 4](https://github.com/Sanjoe27/Local-Business-Padma-Shop-Insights-Dashboard/assets/98551759/76a7d7f3-0cc8-41f3-ab3f-d4fad5151b17)



Conclusion:
After performing the analysis ,I created a interactive dashboard to understand  sales ,region of profit & loss,The final Dashboard was effective at displaying the sales trends,Used different types of customized visualization (bar chart, pie chart, donut chart, clustered bar chart, scatter chart, line chart, area chart, map, slicers, etc) which helped me to figure out a strategy to increase profits,This dashboard could help in increasing the revenue at least by 20% in the next quarter.

Strategy :
From the 1st two graphs on the left,we can have the top 4 products which are giving profits and loss,what we can do is we can maintain the same quantity of stock of products which are bringing profits & minimise the quantity of products which are not selling more,decreasing the stocks will directly refer to profits.
From the donut chart ,we can have the most selling products ,the profit margin may be less for these products but these products will help our promotions as the customers who buys such products will refer to their friends which will increase our stores business.
From the 4th clustered bar graph,We can have the list of loyal customers,we can provide extra discounts ,so that we can build trust among our fellow customers.
Last 2 graphs will give us insights about the percentage of Investment to profit ratio and monthly overall statistics of the store.

Achievement :
At last the project is trust worthy ,the store followed our strategy and in the next quarter they raised their profits by 25% which is greater than predicted.And they gifted me with 3000 rupees of cash.My main motto is to empower small businesses because such stores will feed many families.
Thank You:)

